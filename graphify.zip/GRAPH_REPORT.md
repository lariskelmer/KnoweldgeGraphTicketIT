# Graph Report - .  (2026-04-29)

## Corpus Check
- Corpus is ~36,796 words - fits in a single context window. You may not need a graph.

## Summary
- 16 nodes · 17 edges · 3 communities detected
- Extraction: 35% EXTRACTED · 65% INFERRED · 0% AMBIGUOUS · INFERRED: 11 edges (avg confidence: 0.5)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]

## God Nodes (most connected - your core abstractions)
1. `STELLAR: A Structured, Trustworthy, and Explainable LLM-Led Architecture for Reliable Customer Support` - 7 edges
2. `Smart Serve: Redefining Customer Support with AI-Driven Ticketing Intelligence` - 4 edges
3. `LLM Agents for Smart City Management` - 3 edges
4. `TickIt: Leveraging Large Language Models for Automated Ticket Escalation` - 3 edges
5. `Customer support` - 2 edges
6. `Large language models` - 2 edges
7. `Retrieval-augmented generation` - 2 edges
8. `Cloud service tickets` - 2 edges
9. `Ticket escalation` - 2 edges
10. `Explainable LLM-led architecture` - 1 edges

## Surprising Connections (you probably didn't know these)
- `Smart Serve: Redefining Customer Support with AI-Driven Ticketing Intelligence` --addresses--> `Customer support`  [INFERRED]
  D:\Documentos\Mestrado\T2\graphify\TicketEscalationArticles.pdf → D:\Documentos\Mestrado\T2\graphify\6044-Article Text-37095-1-10-20260304.pdf
- `TickIt: Leveraging Large Language Models for Automated Ticket Escalation` --uses--> `Large language models`  [EXTRACTED]
  D:\Documentos\Mestrado\T2\graphify\TicketEscalationArticles.pdf → D:\Documentos\Mestrado\T2\graphify\6044-Article Text-37095-1-10-20260304.pdf
- `LLM Agents for Smart City Management` --uses--> `Retrieval-augmented generation`  [EXTRACTED]
  D:\Documentos\Mestrado\T2\graphify\smartcities-08-00019-v2.pdf → D:\Documentos\Mestrado\T2\graphify\6044-Article Text-37095-1-10-20260304.pdf

## Communities

### Community 0 - "Community 0"
Cohesion: 0.0
Nodes (7): AI-driven ticketing intelligence, Cloud service tickets, Customer support, Large language models, Smart Serve: Redefining Customer Support with AI-Driven Ticketing Intelligence, Ticket escalation, TickIt: Leveraging Large Language Models for Automated Ticket Escalation

### Community 1 - "Community 1"
Cohesion: 0.0
Nodes (5): Compliance verification, Explainable LLM-led architecture, Human escalation, Knowledge base refinement, STELLAR: A Structured, Trustworthy, and Explainable LLM-Led Architecture for Reliable Customer Support

### Community 2 - "Community 2"
Cohesion: 0.0
Nodes (4): LLM Agents for Smart City Management, Multi-agent systems, Retrieval-augmented generation, Smart city management

## Knowledge Gaps
- **7 isolated node(s):** `Explainable LLM-led architecture`, `Human escalation`, `Knowledge base refinement`, `Compliance verification`, `Smart city management` (+2 more)
  These have ≤1 connection - possible missing edges or undocumented components.